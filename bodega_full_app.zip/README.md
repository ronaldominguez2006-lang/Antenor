
# Bodega Full App

Sistema POS para bodega.

## Incluye
- Escáner por cámara
- Stock
- Ganancias
- Ventas
- Historial
- Modo offline
- GitHub Pages

## Cómo usar

1. Subir archivos a GitHub
2. Ir a Settings > Pages
3. Activar GitHub Pages
4. Abrir el link

